package com.tellmewhere.async;

public class CancelledException extends Exception
{
	private static final long serialVersionUID = 1L;
}